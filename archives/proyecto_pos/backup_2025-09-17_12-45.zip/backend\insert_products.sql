-- Insert products into productos table

-- Pastas
INSERT INTO productos (codigo, nombre, precio, stock, categoria) VALUES ('PAST-001', 'Fideos (tallarín, codito, mostachol, etc.)', 1000, 0, 'Pastas');
INSERT INTO productos (codigo, nombre, precio, stock, categoria) VALUES ('PAST-002', 'Pastas secas en general', 1000, 0, 'Pastas');

-- Cereales y Derivados
INSERT INTO productos (codigo, nombre, precio, stock, categoria) VALUES ('CER-001', 'Arroz blanco', 1750, 0, 'Cereales y Derivados');
INSERT INTO productos (codigo, nombre, precio, stock, categoria) VALUES ('CER-002', 'Arroz integral', 2150, 0, 'Cereales y Derivados');
INSERT INTO productos (codigo, nombre, precio, stock, categoria) VALUES ('CER-003', 'Harina de trigo (000)', 1000, 0, 'Cereales y Derivados');
INSERT INTO productos (codigo, nombre, precio, stock, categoria) VALUES ('CER-004', 'Harina de trigo (0000)', 1100, 0, 'Cereales y Derivados');
INSERT INTO productos (codigo, nombre, precio, stock, categoria) VALUES ('CER-005', 'Harina leudante', 1250, 0, 'Cereales y Derivados');
INSERT INTO productos (codigo, nombre, precio, stock, categoria) VALUES ('CER-006', 'Pan rallado', 800, 0, 'Cereales y Derivados');
INSERT INTO productos (codigo, nombre, precio, stock, categoria) VALUES ('CER-007', 'Rebozador', 900, 0, 'Cereales y Derivados');
INSERT INTO productos (codigo, nombre, precio, stock, categoria) VALUES ('CER-008', 'Maíz (en grano o para pochoclo)', 950, 0, 'Cereales y Derivados');

-- Conservas
INSERT INTO productos (codigo, nombre, precio, stock, categoria) VALUES ('CONS-001', 'Puré de tomate / Tomate triturado', 750, 0, 'Conservas');
INSERT INTO productos (codigo, nombre, precio, stock, categoria) VALUES ('CONS-002', 'Tomate entero / rodajas', 750, 0, 'Conservas');
INSERT INTO productos (codigo, nombre, precio, stock, categoria) VALUES ('CONS-003', 'Arvejas', 650, 0, 'Conservas');
INSERT INTO productos (codigo, nombre, precio, stock, categoria) VALUES ('CONS-004', 'Zanahorias', 650, 0, 'Conservas');
INSERT INTO productos (codigo, nombre, precio, stock, categoria) VALUES ('CONS-005', 'Choclo', 650, 0, 'Conservas');
INSERT INTO productos (codigo, nombre, precio, stock, categoria) VALUES ('CONS-006', 'Atún / Caballa en lata', 1050, 0, 'Conservas');
INSERT INTO productos (codigo, nombre, precio, stock, categoria) VALUES ('CONS-007', 'Sardinas en lata', 800, 0, 'Conservas');

-- Aceites y Vinagres
INSERT INTO productos (codigo, nombre, precio, stock, categoria) VALUES ('ACEI-001', 'Aceite de girasol', 1750, 0, 'Aceites y Vinagres');
INSERT INTO productos (codigo, nombre, precio, stock, categoria) VALUES ('ACEI-002', 'Aceite de maíz', 1850, 0, 'Aceites y Vinagres');
INSERT INTO productos (codigo, nombre, precio, stock, categoria) VALUES ('ACEI-003', 'Aceite de oliva', 2750, 0, 'Aceites y Vinagres');
INSERT INTO productos (codigo, nombre, precio, stock, categoria) VALUES ('ACEI-004', 'Aceite de soja', 1750, 0, 'Aceites y Vinagres');
INSERT INTO productos (codigo, nombre, precio, stock, categoria) VALUES ('ACEI-005', 'Vinagre', 550, 0, 'Aceites y Vinagres');

-- Condimentos y Especias
INSERT INTO productos (codigo, nombre, precio, stock, categoria) VALUES ('COND-001', 'Sal', 400, 0, 'Condimentos y Especias');
INSERT INTO productos (codigo, nombre, precio, stock, categoria) VALUES ('COND-002', 'Pimienta', 450, 0, 'Condimentos y Especias');
INSERT INTO productos (codigo, nombre, precio, stock, categoria) VALUES ('COND-003', 'Orégano', 300, 0, 'Condimentos y Especias');
INSERT INTO productos (codigo, nombre, precio, stock, categoria) VALUES ('COND-004', 'Ají molido', 400, 0, 'Condimentos y Especias');
INSERT INTO productos (codigo, nombre, precio, stock, categoria) VALUES ('COND-005', 'Pimentón', 400, 0, 'Condimentos y Especias');
INSERT INTO productos (codigo, nombre, precio, stock, categoria) VALUES ('COND-006', 'Ajo en polvo', 400, 0, 'Condimentos y Especias');
INSERT INTO productos (codigo, nombre, precio, stock, categoria) VALUES ('COND-007', 'Cebolla en polvo', 400, 0, 'Condimentos y Especias');
INSERT INTO productos (codigo, nombre, precio, stock, categoria) VALUES ('COND-008', 'Caldo en cubos o polvo', 550, 0, 'Condimentos y Especias');

-- Azúcar y Edulcorantes
INSERT INTO productos (codigo, nombre, precio, stock, categoria) VALUES ('AZUC-001', 'Azúcar blanca', 1250, 0, 'Azúcar y Edulcorantes');
INSERT INTO productos (codigo, nombre, precio, stock, categoria) VALUES ('AZUC-002', 'Azúcar impalpable', 1500, 0, 'Azúcar y Edulcorantes');
INSERT INTO productos (codigo, nombre, precio, stock, categoria) VALUES ('AZUC-003', 'Edulcorantes (sobre o líquido)', 700, 0, 'Azúcar y Edulcorantes');

-- Dulces y Mermeladas
INSERT INTO productos (codigo, nombre, precio, stock, categoria) VALUES ('DULC-001', 'Dulce de leche', 1050, 0, 'Dulces y Mermeladas');
INSERT INTO productos (codigo, nombre, precio, stock, categoria) VALUES ('DULC-002', 'Mermelada (frutilla, durazno, etc.)', 900, 0, 'Dulces y Mermeladas');
INSERT INTO productos (codigo, nombre, precio, stock, categoria) VALUES ('DULC-003', 'Miel', 1400, 0, 'Dulces y Mermeladas');

-- Infusiones
INSERT INTO productos (codigo, nombre, precio, stock, categoria) VALUES ('INFU-001', 'Yerba mate', 1600, 0, 'Infusiones');
INSERT INTO productos (codigo, nombre, precio, stock, categoria) VALUES ('INFU-002', 'Café molido', 2000, 0, 'Infusiones');
INSERT INTO productos (codigo, nombre, precio, stock, categoria) VALUES ('INFU-003', 'Café instantáneo', 1400, 0, 'Infusiones');
INSERT INTO productos (codigo, nombre, precio, stock, categoria) VALUES ('INFU-004', 'Café en cápsulas', 1150, 0, 'Infusiones');
INSERT INTO productos (codigo, nombre, precio, stock, categoria) VALUES ('INFU-005', 'Té / Mate cocido (saquitos o hebras)', 550, 0, 'Infusiones');

-- Galletitas y Snacks
INSERT INTO productos (codigo, nombre, precio, stock, categoria) VALUES ('GALL-001', 'Galletitas dulces (de agua, crackers)', 600, 0, 'Galletitas y Snacks');
INSERT INTO productos (codigo, nombre, precio, stock, categoria) VALUES ('GALL-002', 'Galletitas surtidas / rellenas', 800, 0, 'Galletitas y Snacks');
INSERT INTO productos (codigo, nombre, precio, stock, categoria) VALUES ('GALL-003', 'Snacks (papas fritas, maní, palitos)', 700, 0, 'Galletitas y Snacks');

-- Lácteos
INSERT INTO productos (codigo, nombre, precio, stock, categoria) VALUES ('LACT-001', 'Leche en polvo', 1200, 0, 'Lácteos');
INSERT INTO productos (codigo, nombre, precio, stock, categoria) VALUES ('LACT-002', 'Leche UAT (larga vida)', 800, 0, 'Lácteos');

-- Postres y Repostería
INSERT INTO productos (codigo, nombre, precio, stock, categoria) VALUES ('POST-001', 'Premezclas para tortas', 900, 0, 'Postres y Repostería');
INSERT INTO productos (codigo, nombre, precio, stock, categoria) VALUES ('POST-002', 'Flanes en polvo', 400, 0, 'Postres y Repostería');
INSERT INTO productos (codigo, nombre, precio, stock, categoria) VALUES ('POST-003', 'Gelatinas en polvo', 350, 0, 'Postres y Repostería');
INSERT INTO productos (codigo, nombre, precio, stock, categoria) VALUES ('POST-004', 'Cacao en polvo', 600, 0, 'Postres y Repostería');

-- Otros
INSERT INTO productos (codigo, nombre, precio, stock, categoria) VALUES ('OTRO-001', 'Mayonesa', 900, 0, 'Otros');
INSERT INTO productos (codigo, nombre, precio, stock, categoria) VALUES ('OTRO-002', 'Mostaza', 500, 0, 'Otros');
INSERT INTO productos (codigo, nombre, precio, stock, categoria) VALUES ('OTRO-003', 'Ketchup', 800, 0, 'Otros');
INSERT INTO productos (codigo, nombre, precio, stock, categoria) VALUES ('OTRO-004', 'Salsas (soja, picantes, etc.)', 600, 0, 'Otros');
INSERT INTO productos (codigo, nombre, precio, stock, categoria) VALUES ('OTRO-005', 'Tapas para empanadas y tartas', 700, 0, 'Otros');
INSERT INTO productos (codigo, nombre, precio, stock, categoria) VALUES ('OTRO-006', 'Levadura / Leudantes', 500, 0, 'Otros');
INSERT INTO productos (codigo, nombre, precio, stock, categoria) VALUES ('OTRO-007', 'Alfajores', 300, 0, 'Otros');
INSERT INTO productos (codigo, nombre, precio, stock, categoria) VALUES ('OTRO-008', 'Chocolates', 800, 0, 'Otros');